document.getElementById("upload-photo").addEventListener("change", function(event) {
    const userIcon = document.getElementById("user-icon");
    const file = event.target.files[0];

    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            userIcon.src = e.target.result; 
        };
        reader.readAsDataURL(file);
    }
});